# Halogen MCQ Test

This is a sample test for the Halogen Derivatives chapter (Level 1) based on JEE-style MCQs.

**How to use**:
- Upload this repository to GitHub
- Enable GitHub Pages under Settings > Pages
- Access it via: `https://yourusername.github.io/repo-name/`

The file `index.html` will open the interactive test.
